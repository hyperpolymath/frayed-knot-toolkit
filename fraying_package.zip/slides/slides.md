# Slide 1 — From topology to distributions

- Each crossing has two local resolutions (split/join)
- n crossings → 2^n global states
- The diagram (wiring) determines how states reconnect
- Compute fragments per state → not one answer, a distribution

Takeaway:
Topology → distribution of fragment counts

---

# Slide 2 — Tropical summary and experiment

- Compress distribution:
  - support (possible counts)
  - min / max
  - collapse vs spread
- Example:
  - Diagram 1 → {2,3} (spread)
  - Diagram 2′ → {2} (collapse)

Experimental target:
Measure fragment-count histograms under unbiased breakage and compare supports.
